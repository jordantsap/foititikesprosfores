<footer class="footer">
  <div class="footer-area">
    <div class="container">
      <div class="row section_gap">
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="single-footer-widget tp_widgets">
            <h4 class="footer_title large_title">Our Mission</h4>
            <p>
              So seed seed green that winged cattle in. Gathering thing made fly you're no divided
              deep moved us lan Gathering thing us land years living.
            </p>
            <p>
              So seed seed green that winged cattle in. Gathering thing made fly you're no divided
              deep moved
            </p>
          </div>
        </div>
        <div class="offset-lg-1 col-lg-2 col-md-6 col-sm-6">
          <div class="single-footer-widget tp_widgets">
            <h4 class="footer_title">Quick Links</h4>
            <ul class="">
              <li class="footer">
                <a href="#">Home</a>
              </li>
              <li class="footer">
                <a href="#">Shop</a>
              </li>
              <li class="footer">
                <a href="#">Blog</a>
              </li>
              <li class="footer">
                <a href="#">Product</a>
              </li>
              <li class="footer">
                <a href="#">Brand</a>
              </li>
              <li class="footer">
                <a href="#">Contact</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="single-footer-widget instafeed">
            <h4 class="footer_title">Gallery</h4>
            <ul class="list instafeed d-flex flex-wrap">
              <li><img src="img/gallery/r1.jpg" alt=""></li>
              <li><img src="img/gallery/r2.jpg" alt=""></li>
              <li><img src="img/gallery/r3.jpg" alt=""></li>
              <li><img src="img/gallery/r5.jpg" alt=""></li>
              <li><img src="img/gallery/r7.jpg" alt=""></li>
              <li><img src="img/gallery/r8.jpg" alt=""></li>
            </ul>
          </div>
        </div>
        <div class="offset-lg-1 col-lg-3 col-md-6 col-sm-6">
          <div class="single-footer-widget tp_widgets">
            <h4 class="footer_title">Contact Us</h4>
            <div class="ml-40">
              <p class="sm-head">
                <span class="fa fa-location-arrow"></span> Head Office
              </p>
              <p>123, Main Street, Your City</p>
              <p class="sm-head">
                <span class="fa fa-phone"></span> Phone Number
              </p>
              <p>
                +123 456 7890
                <br> +123 456 7890
              </p>
              <p class="sm-head">
                <span class="fa fa-envelope"></span> Email <br>
                <a href="mailto: abc@example.com">Send Email</a>
              </p>
              <p>


              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="row d-flex">
        <p class="col-lg-12 footer-text text-center">

          Copyright &copy;
          <!-- <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
          <script>
            document.write(new Date().getFullYear());
          </script> All rights reserved | This template is designed with <i class="fa fa-heart" aria-hidden="true"></i> by
          <a href="https://colorlib.com" target="_blank">Zerone Hellas</a>
        </p>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/main.js"></script>

</body>

</html>