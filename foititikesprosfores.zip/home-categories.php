<section class="home-categories">
    <div class="">

        <div class="row">
            <div class="mx-auto">
                <h1 class="home-categories-header text-center">Κατηγορίες Προσφορών</h1>
            </div>
            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="home-categories-item">
                <div class="hovereffect">
                    <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                    <div class="overlay">
                        <h2>Effect 12</h2>
                        <p>
                            <a href="#">LINK HERE</a>
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>

</section>