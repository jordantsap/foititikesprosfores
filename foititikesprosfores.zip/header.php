<header class="header_area">
  <div class="main_menu">
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container-fluid">

        <div class="col-sm-4">
          <a class="navbar-brand logo " href="index.php">
            <img src="images/logo.png" alt="foititikesprosfores">
          </a>
        </div>

        <div class="col">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav menu_nav ml-auto mr-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item submenu dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Shop</a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a class="nav-link" href="">Shop Category</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="">Product Details</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="">Product Checkout</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="">Confirmation</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="">Shopping Cart</a>
                  </li>
                </ul>
              </li>
              <li class="nav-item submenu dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Blog</a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a class="nav-link" href="blog.html">Blog</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="single-blog.html">Blog Details</a>
                  </li>
                </ul>
              </li>
              <li class="nav-item submenu dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages</a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a class="nav-link" href="login.html">Login</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="register.html">Register</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="tracking-order.html">Tracking</a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.html">Contact</a>
              </li>
            </ul>
          </div>

        </div>


        <div class="position-end">

          <ul class="list-group list-group-horizontal">
            <li class="list-group-item">
              <i class="fas fa-search"></i>
            </li>
            <li class="list-group-item">
              <i class="fas fa-shopping-cart"></i>
              <span class="nav-shop__circle">3</span>
            </li>
          </ul>
        </div>

      </div>
      <!--CONTAINER-->
    </nav>
  </div>
</header>