<?php include 'head.php'; ?>
<?php include 'header.php'; ?>
<?php include 'slider.php'; ?>

  <?php include "home-categories.php" ?>

  <?php include "home-offers.php" ?>

  <?php include "home-tips-posts.php" ?>
  
  <?php include "footer.php" ?>

