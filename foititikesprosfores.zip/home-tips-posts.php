<section class="home-tips">
    <div class="container">

        <div class="row">
            <div class="mx-auto">
                <h1 class="home-tips-header text-center">Χρήσιμα Tips</h1>
                <hr class="home-tips">
            </div>
            <div class="home-tips-item">
                <a href="#">
                    <!-- <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt=""> -->
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>
            <div class="home-tips-item">
                <a href="#">
                    <!-- <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt=""> -->
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>
            <div class="home-tips-item">
                <a href="#">
                    <!-- <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt=""> -->
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>
            <div class="home-tips-item">
                <a href="#">
                    <!-- <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt=""> -->
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>

        </div>
        
    </div>

</section>

<section class="homeblogposts">
    <div class="container">
        <div class="row">
            
        <div class="row" id="home-blog">
            <div class="mx-auto">
                <h1 class="home-posts-header text-center">Τελευταία Νέα</h1>
                <!-- <hr class="home-categories"> -->
            </div>

            <div class="home-blog-posts-item">
                <a href="#">
                    <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt="">
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>
            <div class="home-blog-posts-item">
                <a href="#">
                    <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt="">
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>
            <div class="home-blog-posts-item">
                <a href="#">
                    <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt="">
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>
            <div class="home-blog-posts-item">
                <a href="#">
                    <img class="" width="100%" height="250px" src="http://placehold.it/350x200" alt="">
                </a>
                <h2><a class="" style="color:#000;" href="#">Lorem, ipsum dolor.</a></h2>
                <h3 class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, numquam!</h3>
            </div>

        </div>
        </div>
    </div>
</section>