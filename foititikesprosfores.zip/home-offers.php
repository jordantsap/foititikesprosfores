<section class="home-offers">
    <div class="container">
        <div class="row">
            <div class="mx-auto">
                <h1 class="home-offers-header text-center">Δείτε Προσφορές</h1>
            </div>
            <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Δημοφιλείς</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Τελευταίες</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Κατηγορία</button>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="hovereffect">
                            <img class="img-responsive" src="http://placehold.it/350x200" alt="">

                            <div class="overlay">
                                <h2>Effect 13</h2>
                                <p>
                                    <a href="#">LINK HERE</a>
                                </p>
                            </div>
                            Κατηγορια
                            <br>
                            Ονομασια
                            <br>
                            Τιμή
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="hovereffect">
                            <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                            <div class="overlay">
                                <h2>Effect 13</h2>
                                <p>
                                    <a href="#">LINK HERE</a>
                                </p>
                            </div>
                            Κατηγορια
                            <br>
                            Ονομασια
                            <br>
                            Τιμή
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="hovereffect">
                            <img class="img-responsive" src="http://placehold.it/350x200" alt="">
                            <div class="overlay">
                                <h2>Effect 13</h2>
                                <p>
                                    <a href="#">LINK HERE</a>
                                </p>
                            </div>
                            Κατηγορια
                            <br>
                            Ονομασια
                            <br>
                            Τιμή
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>